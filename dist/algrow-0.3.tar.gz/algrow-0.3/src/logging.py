from .options import options
import logging


args = options().parse_args()


LOGGING_CONFIG = {
    'version': 1,
    'disable_existing_loggers': True,
    'formatters': {
        'standard': {
            'format': '%(asctime)s [%(levelname)s] %(name)s : %(message)s'
        },
    },
    'handlers': {
        'default': {
            'level': args.loglevel,
            'formatter': 'standard',
            'class': 'logging.StreamHandler',
            'stream': 'ext://sys.stdout',  # Default is stderr
        },
    },
    'loggers': {
        '': {  # root logger  # I prefer to set this as WARNING, otherwise we get debug from loaded packages as well
            'handlers': ['default'],
            'level': 'WARNING',
            'propagate': False
        },
        'src': {
            'handlers': ['default'],
            'level': args.loglevel,
            'propagate': False
        },
        '__main__': {  # if __name__ == '__main__'
            'handlers': ['default'],
            'level': args.loglevel,
            'propagate': False
        },
    }
}


class CustomAdapter(logging.LoggerAdapter):
    def process(self, msg, kwargs):
        return '[%s] %s' % (self.extra['image_filepath'], msg), kwargs
