from .algrow import algrow


if __name__ == '__main__':
    algrow()

