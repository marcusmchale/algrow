#!/usr/bin/env python

from src.discgrow import main

if __name__ == '__main__':
    main()
